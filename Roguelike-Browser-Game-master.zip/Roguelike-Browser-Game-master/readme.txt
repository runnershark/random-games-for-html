Instructions:
To run the project, open project.html in a html5 compatible browser.
To run the tests, open tests.html in a html5 compatible browser.
Instructions to play the game is provided in the game (lower left panel).

Contributors
Hin Yun Lee: Game Logic, Random Dungeon Generation
Husnu Melih Erdogan: GUI, Sound, Graphics
Sahar Daraeizadeh: Pathfinding Algorithm
