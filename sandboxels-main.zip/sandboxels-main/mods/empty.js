// Override this file with your browser's developer tools to test mods locally.

// [Tutorials]
// Chrome: https://developer.chrome.com/docs/devtools/overrides
// Firefox: https://stackoverflow.com/a/38538310
// Microsoft Edge: https://learn.microsoft.com/en-us/microsoft-edge/devtools-guide-chromium/javascript/overrides
// Safari: https://webkit.org/web-inspector/local-overrides/