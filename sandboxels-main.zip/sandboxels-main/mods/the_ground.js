window.addEventListener("load",function() {
	logMessage("the_ground.js is deprecated. Please remove it from your mod list and remove any mods that depend on it (such as nellfire.js or rainbow_earth.js).")
})
