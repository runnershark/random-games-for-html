 elements.wine = {
    color: "#89281D",
    behavior: behaviors.LIQUID,
    category: "food",
    viscosity: 20000,
    state: "liquid",
    density: 380,
}; 
