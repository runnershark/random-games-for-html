elements.water_spout = {
    "color": "rgb(96,99,120)",
    "behavior": [
        [
            "XX",
            "CR:water",
            "XX"
        ],
        [
            "CR:water",
            "XX",
            "CR:water"
        ],
        [
            "XX",
            "CR:water",
            "XX"
        ]
    ],
    "category": "special",
    "colorObject": {
        "r": 96,
        "g": 99,
        "b": 120
    }
}
