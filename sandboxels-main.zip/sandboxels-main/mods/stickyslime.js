window.addEventListener("load",function() {
	logMessage("stickyslime.js has been renamed. plz install stickystuff.js instead, as thats what it was renamed to.")
})
