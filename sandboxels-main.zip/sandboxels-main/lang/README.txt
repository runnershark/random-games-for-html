Translation updates to this GitHub repo are no longer accepted!

If you'd like to contribute translations, you must use the new Crowdin system here: https://crowdin.com/editor/sandboxels

For more information, see the Translation Page: https://sandboxels.r74n.com/translate
