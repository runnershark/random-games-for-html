function set_lvl()
	if init_lvl==1 then
		p.x=60
		p.y=496
	elseif init_lvl==2 then
		p.x=45
		p.y=344
	elseif init_lvl==3 then
		p.x=40
		p.y=232
	elseif init_lvl==4 then
		p.x=17
		p.y=104
	elseif init_lvl==5 then
		p.x=195
		p.y=464
	elseif init_lvl==6 then
		p.x=140
		p.y=368
	elseif init_lvl==7 then
		p.x=164
		p.y=240
	elseif init_lvl==8 then
		p.x=174
		p.y=104
	elseif init_lvl==9 then
		p.x=304
		p.y=488
	elseif init_lvl==10 then
		p.x=360
		p.y=368
	elseif init_lvl==11 then
		p.x=320
		p.y=216
	elseif init_lvl==12 then
		p.x=292
		p.y=104
	elseif init_lvl==13 then
		p.x=486
		p.y=488
	elseif init_lvl==14 then
		p.x=394
		p.y=352
	elseif init_lvl==15 then
		p.x=482
		p.y=200
	elseif init_lvl==16 then
		p.x=441
		p.y=88
	elseif init_lvl==17 then
		p.x=543
		p.y=496
	elseif init_lvl==18 then
		p.x=587
		p.y=352
	elseif init_lvl==19 then
		p.x=548
		p.y=232
	elseif init_lvl==20 then
		p.x=554
		p.y=112
	elseif init_lvl==21 then
		p.x=554
		p.y=112
	elseif init_lvl==22 then
		p.x=554
		p.y=112
	elseif init_lvl==23 then
		p.x=554
		p.y=112
	elseif init_lvl==24 then
		p.x=554
		p.y=112
	elseif init_lvl==25 then
		p.x=554
		p.y=112
	elseif init_lvl==26 then
		p.x=554
		p.y=112
	elseif init_lvl==27 then
		p.x=554
		p.y=112
	elseif init_lvl==28 then
		p.x=554
		p.y=112
	end
end