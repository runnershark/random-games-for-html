function draw_title()
    cls()
    print("press ❎",46,56,blink_c)
end